import os, re, zipfile, shutil, datetime
import pdfplumber
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


# ----------------------------------------------------------
#                     UTILITY FUNCTIONS
# ----------------------------------------------------------

def convert_year(two_digit_year):
    return str(datetime.datetime.now().year // 100) + two_digit_year


def extract_date(text):
    pattern = r"Date\s*:\s*(\d{1,2})-\s*([A-Za-z]{3})-\s*(\d{2})"
    match = re.search(pattern, text)
    if match:
        day, month, year = match.groups()
        return f"{convert_year(year)}-{month}-{day}"
    return None


def extract_field(pattern, text):
    match = re.search(pattern, text)
    return match.group(1).strip() if match else None


def extract_address(text, label):
    BAD_LABELS = ["PO No", "Invoice No"]
    COMPANY_KW = ["LLC", "Limited", "Ltd", "Services", "Operations", "Research", "Glaxo"]

    pattern = rf"{label}\s*:\s*(.+?)(?=\n\S+:|$)"
    match = re.search(pattern, text, re.DOTALL)
    if not match:
        return None

    lines = [line.strip() for line in match.group(1).split("\n") if line.strip()]
    clean_lines = [line for line in lines if not any(bad.lower() in line.lower() for bad in BAD_LABELS)]
    company = [line for line in clean_lines if any(kw in line for kw in COMPANY_KW)]
    rest = [line for line in clean_lines if line not in company]
    return ", ".join((company + rest)[:6])


def extract_text_from_pdf(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        return "\n".join(p.extract_text() or "" for p in pdf.pages)


def extract_line_items(text):
    pattern = r"^\s*(\d+)\s+(.+?)\s+([\d,.]+)\s+([\d,.]+)\s+([\d,.]+)\s*$"
    items = []

    for line in text.splitlines():
        match = re.match(pattern, line)
        if match:
            _, desc, qty, rate, amount = match.groups()
            items.append({
                "Description": desc.strip(),
                "Quantity": qty.replace(",", ""),
                "Rate": rate.replace(",", ""),
                "Amount": amount.replace(",", "")
            })
    return items


# ----------------------------------------------------------
#             FIXED + ROBUST MAPPING FUNCTION
# ----------------------------------------------------------

def load_invoice_folder_mapping(mapping_excel):
    df = pd.read_excel(mapping_excel)

    # Clean column names: strip + remove non-breaking spaces
    df.columns = df.columns.str.strip().str.replace("\xa0", " ", regex=False)

    required = ["Invoice Name", "Folder Name"]
    for col in required:
        if col not in df.columns:
            print(" Column missing. Excel has:", df.columns.tolist())
            raise KeyError(f"Column '{col}' not found in mapping sheet!")

    df["Invoice Name"] = df["Invoice Name"].astype(str).str.strip()
    df["Folder Name"] = df["Folder Name"].astype(str).str.strip()

    return dict(zip(df["Invoice Name"], df["Folder Name"]))


# ----------------------------------------------------------
#                FILE CATEGORIZATION (FIXED)
# ----------------------------------------------------------

def categorize_files(temp_folder, mapping_dict):
    file_folder_map = {}

    for file_name in os.listdir(temp_folder):
        file_path = os.path.join(temp_folder, file_name)

        if not os.path.isfile(file_path) or not file_name.lower().endswith(".pdf"):
            continue

        matched_folder = None
        for invoice_name, folder_name in mapping_dict.items():

            # more flexible matching
            if invoice_name.lower() in file_name.lower():
                matched_folder = folder_name
                break

        if matched_folder:
            folder_path = os.path.join(temp_folder, matched_folder)
            os.makedirs(folder_path, exist_ok=True)
            shutil.move(file_path, os.path.join(folder_path, file_name))
            file_folder_map[file_name] = matched_folder
        else:
            file_folder_map[file_name] = "Unmapped"

    return file_folder_map


# ----------------------------------------------------------
#             PDF PROCESSING FUNCTION
# ----------------------------------------------------------

def process_pdfs(base_folder, file_folder_map, data):
    for root, _, files in os.walk(base_folder):
        for file_name in files:
            if not file_name.lower().endswith(".pdf"):
                continue

            pdf_path = os.path.join(root, file_name)
            text = extract_text_from_pdf(pdf_path)

            po_no = extract_field(r"PO No\.\s*:\s*(\d+)", text)
            attention = extract_field(r"Attention\s*:\s*([\w\s/&\-']+)", text)
            invoice_no = extract_field(r"Invoice No\.?\s*:\s*(.+)", text)
            bill_to = extract_address(text, "Bill To")
            service_to = extract_address(text, "Service To")
            total = extract_field(r"Total\s*:\s*([\d,.]+)", text)
            date = extract_date(text)

            folder_name = file_folder_map.get(file_name, os.path.basename(root))

            line_items = extract_line_items(text)

            if not line_items:
                data.append({
                    "File Name": file_name,
                    "PO No": po_no,
                    "Attention": attention,
                    "Invoice No": invoice_no,
                    "Bill To": bill_to,
                    "Service To": service_to,
                    "Description": None,
                    "Quantity": None,
                    "Rate": None,
                    "Amount": None,
                    "Total": total,
                    "Date": date,
                    "Folder Name": folder_name
                })
            else:
                for item in line_items:
                    data.append({
                        "File Name": file_name,
                        "PO No": po_no,
                        "Attention": attention,
                        "Invoice No": invoice_no,
                        "Bill To": bill_to,
                        "Service To": service_to,
                        "Description": item["Description"],
                        "Quantity": item["Quantity"],
                        "Rate": item["Rate"],
                        "Amount": item["Amount"],
                        "Total": total,
                        "Date": date,
                        "Folder Name": folder_name
                    })


# ----------------------------------------------------------
#                   EXCEL STYLING
# ----------------------------------------------------------

def style_excel(file_path):
    wb = load_workbook(file_path)
    ws = wb.active

    header_fill = PatternFill(start_color="BDD7EE", end_color="BDD7EE", fill_type="solid")
    bold = Font(bold=True)

    wrap = Alignment(wrap_text=True, vertical="top")

    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = bold
        cell.alignment = wrap

    for i, row in enumerate(ws.iter_rows(min_row=2), start=2):
        fill_color = "F2F2F2" if i % 2 == 0 else "FFFFFF"
        for cell in row:
            cell.fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
            cell.alignment = wrap

    # Auto column width
    for col in ws.columns:
        max_len = max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[get_column_letter(col[0].column)].width = max_len + 4

    wb.save(file_path)
    print(f" Styled Excel saved: {file_path}")


# ----------------------------------------------------------
#                        MAIN
# ----------------------------------------------------------

def main(zip_file, mapping_excel, output_excel):
    temp_folder = "mapped_pdf_folder"
    os.makedirs(temp_folder, exist_ok=True)

    data = []

    # Unzip PDFs
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        zip_ref.extractall(temp_folder)

    # Load mapping
    mapping = load_invoice_folder_mapping(mapping_excel)

    # Categorize files into folders
    file_map = categorize_files(temp_folder, mapping)

    # Process PDFs
    process_pdfs(temp_folder, file_map, data)

    # Export to Excel
    df = pd.DataFrame(data)
    df.to_excel(output_excel, index=False)

    # Style Excel
    style_excel(output_excel)

    print(f"\n Completed successfully — Saved to '{output_excel}'")


if __name__ == "__main__": #(zip-file, input-file, output-file)
    main("Invoices.zip", "Invoice Details to upload.xlsx", "consolidated_invoice_data_Aug26.xlsx")
